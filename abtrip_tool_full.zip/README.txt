ABTRIP Content Tool (Full HTML)

Cách sử dụng:
1. Giải nén file zip này.
2. Double-click mở file index.html bằng Chrome/Edge/Firefox.
   -> Tool sẽ chạy trực tiếp (offline).
3. Nhập Topic / Facts / CTA -> bấm Generate outputs để sinh caption.
4. Media Lab:
   - Tab Ảnh (free): tạo ảnh AI (Pollinations) hoặc tìm ảnh Wikimedia.
   - Tab Video (free): Render video -> tải .webm, Export .srt, Convert sang MP4.

Đưa online (Netlify Drop):
- Vào https://app.netlify.com/drop
- Kéo thả file index.html -> sẽ có link public để team dùng.

Hoặc dùng GitHub Pages:
- Tạo repo public, upload file index.html.
- Vào Settings -> Pages -> Deploy from branch.
- Link sẽ dạng: https://<username>.github.io/<repo>/
